const userSchema = require('../models/user.model');
const { body } = require("express-validator");
const bcrypt = require('bcrypt');
const saltRounds = 10;
const jwt = require('jsonwebtoken');


exports.register = [
    body('name').isLength({ min: 1 }).trim().withMessage('A name is required'),
    body('email').isLength({ min: 1 }).trim().withMessage('An email is required'),
    body('password').isLength({ min: 1 }).trim().withMessage('password is required'),

    async (req, res) => {
        try {
            let { name, email, password } = req.body;

            const hashedPassword = await bcrypt.hash(password, saltRounds)

            let userData = {
                name: name,
                email: email,
                password: hashedPassword
            }
            console.log(userData);
            const user = await userSchema.create(userData);

            if (user) {
                return res.status(200).json({
                    status: "success",
                    message: "user created"
                })
            }
        }
        catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]


exports.login = [
    body('email').isLength({ min: 1 }).trim().withMessage('An email is required'),
    body('password').isLength({ min: 1 }).trim().withMessage('password is required'),

    async (req, res) => {
        try {
            console.log("req is", 4);

            let { email, password } = req.body;

            const user = await userSchema.findOne({ email: email });
            if (!user) {
                res.status(400).json({
                    status: 'fail',
                    message: 'invalid data sent'
                });
            }
            else if (await bcrypt.compare(password, user.password)) {
                const tokenPayload = {
                    email: user.email,
                    name: user.name
                };

                const accessToken = jwt.sign(tokenPayload, 'SECRET');

                //save to db
                let updatedUser = await userSchema.updateOne({ token: accessToken });

                res.status(201).json({
                    status: 'success',
                    message: 'User Logged In!',
                    data: {
                        accessToken,
                    },
                });
            } else {
                res.status(400).json({
                    status: 'fail',
                    message: "invalid password",
                });
            }
        }
        catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]