const upload = require('../models/uploader.model');
const { body } = require("express-validator");
const multer = require('multer');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs');


exports.uploadFile = [

    async (req, res) => {
        try {
            console.log("req file", req.file);
            // Check if a file was uploaded
            if (!req.file) {
                return res.status(400).json({ error: 'No file uploaded' });
            }

            const uploadedFilePath = req.file.path;

            // Define the path for the resized image
            const resizedImagePath = path.join('uploads', 'resized-' + req.file.filename);

            // Resize the image using Sharp.js
            sharp(uploadedFilePath)
                .resize(200, 200) // Adjust the width and height as needed
                .jpeg({ quality: 80 }) // Adjust the quality as needed (0-100)
                .toFormat('png') // Change the format to PNG
                .toFile(resizedImagePath, async (err, info) => {
                    if (err) {
                        console.error(err);
                        return res.status(500).json({ error: 'Error resizing the image' });
                    }

                    // save the file to database
                    var img = await upload.create({
                        filename: resizedImagePath
                    });

                    // Respond with a success message and the path to the resized image
                    res.status(200).json({
                        message: 'File uploaded and resized successfully',
                        resizedImagePath: resizedImagePath,
                    });
                });
        }
        catch (err) {
            console.log("err", err);
            res.status(400).json({
                status: 'fail',
                message: 'invalid data sent'
            });
        }
    }
]