const express = require('express');
const app = express();
const bodyParser = require('body-parser');


// EXPRESS ROUTERS
const files = require('./routes/fileUploader');
const user = require('./routes/user');


// MIDDLEWARES
// middleware to provide the "request data" in json format.
app.use(bodyParser.urlencoded({ extended: true }));


// ROUTES
app.use('/api/v1/files', files);
app.use('/api/v1/users', user);


module.exports = app;