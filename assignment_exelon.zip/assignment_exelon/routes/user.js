const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');


const user = require('../controllers/users.controllers');


// for locations
router.post('/register', user.register);
router.post('/login', user.login);


module.exports = router;