const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');


const fileUploads = require('../controllers/uploads.controllers');


// Define the storage location and filename for uploaded files
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads'); // Directory to store uploaded files
    },
    filename: (req, file, cb) => {
        const extname = path.extname(file.originalname);
        cb(null, Date.now() + extname); // Unique filename
    },
});

const upload = multer({ storage });

// for locations
router.post('/upload-file', upload.single("image"), fileUploads.uploadFile);


module.exports = router;